=============================
Orienter classes (docstrings)
=============================


Orienter
========

.. autoclass:: sympy.vector.orienters.Orienter
   :members:


AxisOrienter
============

.. autoclass:: sympy.vector.orienters.AxisOrienter
   :members:

   .. automethod:: sympy.vector.orienters.AxisOrienter.__init__


BodyOrienter
============

.. autoclass:: sympy.vector.orienters.BodyOrienter
   :members:

   .. automethod:: sympy.vector.orienters.BodyOrienter.__init__

SpaceOrienter
=============

.. autoclass:: sympy.vector.orienters.SpaceOrienter
   :members:

   .. automethod:: sympy.vector.orienters.SpaceOrienter.__init__


QuaternionOrienter
==================

.. autoclass:: sympy.vector.orienters.QuaternionOrienter
   :members:

   .. automethod:: sympy.vector.orienters.QuaternionOrienter.__init__
