================================
Essential Functions (Docstrings)
================================

dynamicsymbols
--------------

.. autofunction:: sympy.physics.vector.dynamicsymbols


dot
---

.. autofunction:: sympy.physics.vector.functions.dot


cross
-----

.. autofunction:: sympy.physics.vector.functions.cross


outer
-----

.. autofunction:: sympy.physics.vector.functions.outer


express
-------

.. autofunction:: sympy.physics.vector.functions.express


time_derivative
---------------

.. autofunction:: sympy.physics.vector.functions.time_derivative
