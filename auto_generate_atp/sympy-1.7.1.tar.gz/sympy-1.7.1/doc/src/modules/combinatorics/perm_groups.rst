.. _combinatorics-perm_groups:

Permutation Groups
==================

.. module:: sympy.combinatorics.perm_groups

.. autoclass:: PermutationGroup
   :members:
   :private-members:
   :special-members:
