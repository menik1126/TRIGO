.. _combinatorics-polyhedron:

Polyhedron
==========

.. module:: sympy.combinatorics.polyhedron

.. autoclass:: Polyhedron
   :members:
