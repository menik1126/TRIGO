Curves
------

.. module:: sympy.geometry.curve

.. autoclass:: Curve
   :members:
