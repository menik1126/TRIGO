.. _holonomic-docs:

=========
Holonomic
=========

.. automodule:: sympy.holonomic

Contents
========

.. toctree::
   :maxdepth: 2

   about.rst
   represent.rst
   operations.rst
   convert.rst
   uses.rst
   internal.rst
