======
Assume
======

.. automodule:: sympy.assumptions.assume
   :members:
