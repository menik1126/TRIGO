======
Common
======

.. automodule:: sympy.assumptions.handlers.common
   :members:
