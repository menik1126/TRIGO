========
Handlers
========

.. automodule:: sympy.assumptions.handlers

Contents
========

.. toctree::
    :maxdepth: 3

    calculus.rst
    common.rst
    matrices.rst
    ntheory.rst
    order.rst
    sets.rst
